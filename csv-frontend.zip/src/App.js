import CsvGen from './components/Csv';
import './App.css';

function App() {
  return (
    <CsvGen/>
  );
}

export default App;
